Action()
{

	web_url("rest", 
		"URL=http://52.51.66.38/tech/rest", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../api/FriendApi/", ENDITEM, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		"Url=../api/FriendApi/1", ENDITEM, 
		LAST);

	lr_think_time(9);

	web_custom_request("FriendApi", 
		"URL=http://52.51.66.38/api/FriendApi/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://52.51.66.38/tech/rest", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=utf-8", 
		"Body={\"FirstName\":\"1\",\"LastName\":\"2\",\"City\":\"3\",\"Country\":\"4\",\"Age\":\"5\",\"Notes\":\"6\"}", 
		LAST);

	return 0;
}